# Uses a set instead of a dict. Completely same logic

import sys  
data = set()  

n = int(input())  
for _ in range(n):  
    op, val = sys.stdin.readline().split()  
    if op == 'find':  
        print('yes' if val in data else 'no')  
    else:  
        data.add(val)  