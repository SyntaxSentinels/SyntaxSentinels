# Renamed variables, restructured code

import sys  
storage = {}  

count = int(input())  
for line in sys.stdin:  
    cmd, key = line.strip().split()  
    if cmd == 'find':  
        print('yes' if key in storage else 'no')  
    else:  
        storage[key] = None  # Value irrelevant  