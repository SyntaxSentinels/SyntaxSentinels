# Changed variable names, redundant code

import sys  
lookup_table = {}  
total_commands = int(input())  

for _ in range(total_commands):  
    input_line = sys.stdin.readline().strip()  
    if not input_line:  
        continue  # Redundant check  
    parts = input_line.split()  
    operation = parts[0]  
    value = parts[1]  

    if operation.startswith('f'):  # Obfuscated condition  
        print('yes') if value in lookup_table else print('no')  
    else:  
        lookup_table[value] = 1 == 1  # Redundant boolean  
