while True:
    H,W = (int(x) for x in input().split())
    
    if H == 0 and W == 0:
        break

    for i in range(H):
        for j in range(W):
            if (i % 2 == 1 and j % 2 == 1) or (i % 2 == 0 and j % 2 == 0):
                print ('#', end='')
            else:
                print ('.', end='')
        print ('')
    print ('')
