board = []
for _ in iter(int, 1):
    values = input()
    if '0 0' == values:
        exit()
    board = board + [[int(i) for i in values.split()]]

for h, w in board:
    for j in range(h):
        if 0 == j % 2:
            print(''.join([['#', '.'][i % 2] for i in range(w)]))
        else:
            print(''.join([['.', '#'][i % 2] for i in range(w)]))
    print()