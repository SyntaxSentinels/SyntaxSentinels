while True:
    rows, cols = map(int, input().split())
    if rows == 0 and cols == 0:
        break
    for row_index in range(rows):
        line_output = ""
        for col_index in range(cols):
            if (row_index + col_index) % 2 == 0:
                line_output += "#"
            else:
                line_output += "."
        print(line_output)
    print()