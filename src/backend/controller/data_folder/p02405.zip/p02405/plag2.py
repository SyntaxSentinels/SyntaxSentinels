def generate_pattern():
    while True:
        height, width = map(int, input().split())
        if height == 0 and width == 0:
            break
        
        for row in range(height):
            line = "".join("#" if (row + col) % 2 == 0 else "." for col in range(width))
            print(line)
        print()

generate_pattern()
