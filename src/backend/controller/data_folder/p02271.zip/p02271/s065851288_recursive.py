# Renamed variables, and use recursion to get all subsets

def solve(n, A, q, queries):  
    sums = set()  
    def dfs(index, total):  
        if index == n:  
            sums.add(total)  
            return  
        dfs(index + 1, total + A[index])  
        dfs(index + 1, total)  
    dfs(0, 0)  
    for x in queries:  
        print("yes" if x in sums else "no")  

n = int(input())  
A = list(map(int, input().split()))  
q = int(input())  
m = list(map(int, input().split()))  
solve(n, A, q, m)  