# Uses BFS to generate all subsets. Renamed variables as well.

from collections import deque  

def solve(n, A, q, m):  
    sums = set()  
    queue = deque([0])  
    while queue:  
        current = queue.popleft()  
        for num in A:  
            next_sum = current + num  
            if next_sum not in sums:  
                sums.add(next_sum)  
                queue.append(next_sum)  
    for x in m:  
        print("yes" if x in sums else "no")  

n = int(input())  
A = list(map(int, input().split()))  
q = int(input())  
m = list(map(int, input().split()))  
solve(n, A, q, m)  