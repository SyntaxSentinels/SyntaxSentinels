# Using itertools.combinations instead of bitshifting technique, and renamed variables

import itertools  

def check_sums(n, A, q, m):  
    sum_set = set()  
    for r in range(n+1):  
        for subset in itertools.combinations(A, r):  
            sum_set.add(sum(subset))  
    for num in m:  
        print("yes" if num in sum_set else "no")  

n = int(input())  
A = list(map(int, input().split()))  
q = int(input())  
m = list(map(int, input().split()))  
check_sums(n, A, q, m)  