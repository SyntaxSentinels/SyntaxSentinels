# For loops turned into While loops

def modified_selection(arr):  
    counter = 0  
    i = 0  
    while i < len(arr):  # Changed for-loop to while-loop  
        min_pos = i  
        j = i  
        while j < len(arr):  
            if arr[j] < arr[min_pos]:  
                min_pos = j  
            j += 1  
        if min_pos != i:  
            arr[i], arr[min_pos] = arr[min_pos], arr[i]  
            counter += 1  
        i += 1  
    return arr, counter  

if __name__ == '__main__':
    size = int(input())  
    result, total = modified_selection(list(map(int, input().split())))  
    print(' '.join(map(str, result)))  
    print(total)  