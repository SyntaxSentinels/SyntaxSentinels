# Reversed the loop direction

def selection_sort(A):  
    swaps = 0  
    for i in range(len(A)):  
        min_j = i  
        # Iterate backward (same result)  
        for j in reversed(range(i, len(A))):  
            if A[j] < A[min_j]:  
                min_j = j  
        if i != min_j:  
            A[i], A[min_j] = A[min_j], A[i]  
            swaps += 1  
    return A, swaps  

if __name__ == '__main__':  
    n = int(input())  
    arr, swaps = selection_sort(list(map(int, input().split())))  
    print(' '.join(map(str, arr)))  
    print(swaps)  