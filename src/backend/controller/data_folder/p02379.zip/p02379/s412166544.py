import math
m=[float(i)for i in input().split()]
x=m[2]-m[0]
y=m[3]-m[1]
print(math.sqrt(float(x*x+y*y)))