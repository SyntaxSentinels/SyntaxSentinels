x,y,xx,yy=map(float, input().split())
print('%5f'%((x-xx)**2+(y-yy)**2)**0.5)