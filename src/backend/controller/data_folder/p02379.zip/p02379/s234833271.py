import math
point=list(map(float,input().split()))
print(math.sqrt(pow(point[2]-point[0],2)+pow(point[3]-point[1],2)))