# Read two points from user input
point1_x, point1_y, point2_x, point2_y = map(float, input("Enter coordinates x1 y1 x2 y2: ").split())

# Calculate differences in coordinates
delta_x = point2_x - point1_x
delta_y = point2_y - point1_y

# Compute and print Euclidean distance between points
distance = (delta_x ** 2 + delta_y ** 2) ** 0.5
print(f"Distance between points: {distance}")