a,b,c,d=map(float,input().split())
x=abs(a-c)
y=abs(b-d)
z=x**2+y**2
print(pow(z,0.5))
