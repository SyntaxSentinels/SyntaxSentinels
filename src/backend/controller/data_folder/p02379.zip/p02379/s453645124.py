#ITP1_10-A Distance
x1,y1,x2,y2 = input().split(" ")
x1=float(x1)
y1=float(y1)
x2=float(x2)
y2=float(y2)
print ( ((x1-x2)**2.0 + (y1-y2)**2.0 )**0.5)