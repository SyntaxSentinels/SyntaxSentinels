x = list(map(float,input().split()))

y = round(((x[0]-x[2])**2 + (x[1]-x[3])**2)**0.5,8)

print(y)
