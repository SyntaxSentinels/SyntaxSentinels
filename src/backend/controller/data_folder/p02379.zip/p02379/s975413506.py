from math import hypot
a, b, c, d = map(float, input().split())
print(hypot(a-c, b-d))
