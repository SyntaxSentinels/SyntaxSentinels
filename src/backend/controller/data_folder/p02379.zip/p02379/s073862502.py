x1,y1,x2,y2 = [float(s) for s in input().split(' ')]

print(((x1-x2)**2 + (y1-y2)**2)**0.5)