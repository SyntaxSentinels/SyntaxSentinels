o,p,q,r = [float(i) for i in input().split()]
print(format(((q-o)**2+(r-p)**2)**(1/2), '.8f'))