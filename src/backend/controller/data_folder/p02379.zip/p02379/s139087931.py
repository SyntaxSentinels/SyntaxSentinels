v,w,x,y=map(float,input().split())
print(float((abs(v-x)**2)+abs(w-y)**2)**(1/2))