a,b,c,d = map(float,input().split())
temp = ((a-c)**2+(b-d)**2)**0.5
print(temp)
