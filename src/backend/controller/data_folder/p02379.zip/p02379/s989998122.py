a,b,c,d=map(float,input().split())
z=((a-c)**2+(b-d)**2)**(1/2)
print(z)