import math

x1,y1,x2,y2=map(float,input().split())

a = ((x1-x2)**2)+((y1-y2)**2)

a = math.sqrt(a)

print('{:.8f}'.format(a))
