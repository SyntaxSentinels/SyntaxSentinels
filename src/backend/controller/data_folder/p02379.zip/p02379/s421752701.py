import math
x,y,a,b=map(float, raw_input().split())
print math.sqrt((a-x)**2+(b-y)**2)