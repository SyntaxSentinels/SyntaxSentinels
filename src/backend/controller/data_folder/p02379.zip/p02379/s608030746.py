import math
a,b,c,d=map(float,input().split())
x=(a-c)**2
y=(b-d)**2

l=math.sqrt(x+y)
print(l)
