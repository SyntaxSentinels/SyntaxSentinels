x1,y1,x2,y2=map(float,raw_input().split())
x=x2-x1
y=y2-y1
print (x**2+y**2)**0.5