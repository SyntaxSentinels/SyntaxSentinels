data = list(map(float, input().split()))
print(((data[2]-data[0])**2+(data[3]-data[1])**2)**0.5)

