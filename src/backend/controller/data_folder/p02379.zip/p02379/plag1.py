import math

pos = [int(i) for i in input().split()]
x = pos[2] - pos[0]
y = pos[3] - pos[1]

print(math.sqrt(x**2 + y**2))
