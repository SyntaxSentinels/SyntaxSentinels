a,b,c,d=map(float,input().split())
k=((c-a)*(c-a)+(d-b)*(d-b))**(1/2)
print('{:8f}'.format(k))
