x,y,p,q=map(float,input().split())
print(((x-p)**2+(y-q)**2)**(1/2))
