a,b,c,d=map(float,input().split())
e=(c-a)**2
f=(d-b)**2
print(f"{(e+f)**(1/2):.8f}")
