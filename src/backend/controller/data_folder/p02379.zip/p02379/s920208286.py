import math
x,y,x2,y2 = map(float, raw_input().split())
print '%.7f' % math.sqrt((x-x2)**2 + (y-y2)**2) 