from math import sqrt 
a,b,c,d=map(float,input().split())
e=sqrt((c-a)**2+(d-b)**2)
print(e)

