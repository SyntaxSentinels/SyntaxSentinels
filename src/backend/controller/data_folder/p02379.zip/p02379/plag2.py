coords = map(float, input().split())
x_start, y_start, x_end, y_end = coords
dx, dy = x_end - x_start, y_end - y_start
distance = (dx ** 2 + dy ** 2) ** 0.5
print(distance)
