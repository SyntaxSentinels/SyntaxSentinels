from math import sqrt
x_1,y_1,x_2,y_2=map(float,raw_input().split(" "))
print sqrt((x_1-x_2)**2 + (y_1-y_2)**2)