#coding:utf-8
#1_10_A 2015.4.10
import math

x1,y1,x2,y2 = list(map(float,input().split()))
distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
print('{:.5f}'.format(distance))