A,B,C,D=map(float,input().split())
E=(C-A)**2

F=(D-B)**2

print((float)(E+F)**(1/2))
