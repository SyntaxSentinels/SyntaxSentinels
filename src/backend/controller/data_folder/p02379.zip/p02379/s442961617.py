import math
x1, y1, x2, y2 = map(float, input().split())
a = x2 - x1
b = y2 - y1
print(math.sqrt(a**2 + b**2))
