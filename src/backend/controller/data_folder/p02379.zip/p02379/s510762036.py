a,b,c,d=map(float,input().split())

import math

x=math.sqrt((c-a)**2+(d-b)**2)

print("{:.5f}".format(x))
