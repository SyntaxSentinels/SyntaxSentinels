a,b,c,d=list(map(float,input().split()))
print('%.5f'%(((c-a)**2+(b-d)**2)**.5))