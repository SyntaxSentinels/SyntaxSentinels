a=list(map(float,input().split()))
print((abs(a[0]-a[2])**2+abs(a[1]-a[3])**2)**(1/2))

