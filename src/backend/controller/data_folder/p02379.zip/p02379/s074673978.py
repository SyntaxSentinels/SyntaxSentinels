a,b,c,d = map(float,input().split())
print(abs(complex(c-a,d-b)))