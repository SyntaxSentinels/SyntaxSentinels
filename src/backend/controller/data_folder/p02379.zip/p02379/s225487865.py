import math
a,b,c,d = map(float,input().split())
print(math.sqrt(((c-a)**2) + ((d-b)**2)))
