x=list(map(float,input().split()))
x1,y1,x2,y2=x[0],x[1],x[2],x[3]
print(((x1-x2)**2 + (y1-y2)**2)**0.5)