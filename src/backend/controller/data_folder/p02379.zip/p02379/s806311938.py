import math
x1, y1, x2, y2 = map(float, input().split())
X = x1 - x2
Y = y1 - y2
print('{:.5f}'.format(math.sqrt(X * X + Y * Y)))

