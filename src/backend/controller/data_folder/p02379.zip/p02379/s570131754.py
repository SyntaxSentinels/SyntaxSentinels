a,b,c,d=map(float,input().split())
dx=a-c
dy=b-d
dd=(dx*dx+dy*dy)**.5
print(dd)
