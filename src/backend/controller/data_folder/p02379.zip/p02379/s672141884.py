
a,b,c,d=map(float,input().split())

x=c-a
y=d-b

print((x**2+y**2)**(1/2))
