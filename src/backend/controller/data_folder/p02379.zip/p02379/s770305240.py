(n,m,o,p) = map(float, raw_input().split())
print ((n-o)**2 + (m-p)**2)**0.5