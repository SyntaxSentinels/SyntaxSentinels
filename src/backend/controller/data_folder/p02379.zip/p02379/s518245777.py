import math
n=input().split()
x=float(n[2])-float(n[0])
y=float(n[3])-float(n[1])

print(math.sqrt(x**2+y**2))

