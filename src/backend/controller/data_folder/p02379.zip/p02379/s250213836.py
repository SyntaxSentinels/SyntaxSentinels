import math
a,aa,b,bb=map(float,input().split())
A=(math.sqrt(abs(a-b)**2+abs(aa-bb)**2))
print(A)
