import math
x_1,y_1,x_2,y_2 = map(float,input().split())
print(math.sqrt((x_1-x_2)**2+(y_1-y_2)**2))
