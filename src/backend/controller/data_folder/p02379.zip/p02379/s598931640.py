a, b, c, d = map(float, input().split())                                    
print(pow((c - a)**2 + (d - b)**2, 0.5))