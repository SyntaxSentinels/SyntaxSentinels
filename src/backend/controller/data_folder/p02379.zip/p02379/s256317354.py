import math as mt
x = list(map(float,input().split()))

a = ((x[0]-x[2])**2)+((x[1]-x[3])**2)


print(mt.sqrt(a))
