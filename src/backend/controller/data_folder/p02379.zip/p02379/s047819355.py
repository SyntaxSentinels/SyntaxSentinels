import math
i=list(map(float,input().split()))
x=(i[2]-i[0])**2
y=(i[3]-i[1])**2
print(math.sqrt(x+y))



