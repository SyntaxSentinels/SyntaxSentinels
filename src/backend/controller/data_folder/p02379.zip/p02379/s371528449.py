import math
x1,y1,x2,y2 = input().split( )
x = float(x1)-float(x2)
y = float(y1)-float(y2)
print(math.sqrt(x**2+y**2))

