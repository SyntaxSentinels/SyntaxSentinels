# Variable renaming

input_str = input().strip()  
back_stack = []  
area_stack = []  

total = 0  
length = len(input_str)  

for idx in range(length):  
    if input_str[idx] == "\\":  
        back_stack.append(idx)  
    elif input_str[idx] == "/" and back_stack:  
        j = back_stack.pop()  
        current_area = idx - j  
        total += current_area  

        # Merge nested areas  
        while area_stack and area_stack[-1][0] > j:  
            current_area += area_stack.pop()[1]  
        area_stack.append((j, current_area))  

print(total)  
print(len(area_stack), *(val for pos, val in area_stack))