input_str = input().strip()  
back_stack = []  
area_records = []  

total_volume = 0  
str_length = len(input_str)  
i = 0  

while i < str_length:  
    char = input_str[i]  
    if char == "\\":  
        back_stack.append(i)  
    elif char == "/" and back_stack:  
        start_idx = back_stack.pop()  
        current_area = i - start_idx  
        total_volume += current_area  

        # Merge overlapping areas  
        while area_records and area_records[-1][0] > start_idx:  
            current_area += area_records.pop()[1]  
        area_records.append((start_idx, current_area))  
    i += 1  

print(total_volume)  
print(len(area_records), *(area for pos, area in area_records))