s = input().strip()  
back_indices = []  
results = []  

total_water = 0  
for i, char in enumerate(s):  
    if char == "\\":  
        back_indices.append(i)  
    elif char == "/" and back_indices:  
        j = back_indices.pop()  
        area = i - j  
        total_water += area  

        # Rebuild merged areas  
        temp = []  
        while results and results[-1][0] > j:  
            temp.append(results.pop())  
        if temp:  
            area += sum(val for _, val in temp)  
        results.append((j, area))  

print(total_water)  
print(len(results), *(val for _, val in results))  