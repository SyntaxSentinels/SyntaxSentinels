import math
while 1:
	n = input()
	if n == 0:
		break
	x = map(float,raw_input().split())
	m = float(sum(x)/n)
	s = 0
	for i in x:
		s += (i-m) ** 2
	print math.sqrt(s/n)