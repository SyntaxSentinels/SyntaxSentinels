import math

def calculate_std_dev(values):
    mean = sum(values) / len(values)
    variance = sum((x - mean) ** 2 for x in values) / len(values)
    return math.sqrt(variance)

def main():
    while True:
        num_elements = int(input("Enter the number of elements (0 to exit): "))
        if num_elements == 0:
            break

        user_input = input("Enter the elements separated by spaces: ")
        numbers = list(map(int, user_input.split()))

        if len(numbers) != num_elements:
            print("Error: Number of elements does not match the specified count.")
            continue

        std_dev = calculate_std_dev(numbers)
        print(f"Standard Deviation: {std_dev}")

if __name__ == "__main__":
    main()
