import math
j = 1
for i in range (j):

    count = int(input("Enter number of elements (0 to exit): "))
    if count == 0:
        exit()

    values = list(map(int, input("Enter the elements separated by space: ").split()))
    average = sum(values) / len(values)
    variance_sum = sum((item - average) ** 2 for item in values)
    std_deviation = math.sqrt(variance_sum / count)

    print(f'{std_deviation:.8f}')
    j+=1

