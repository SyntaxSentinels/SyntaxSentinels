import math
while 1:
	n=input()
	if n==0:break
	l=map(int,raw_input().split())
	sum=0
	for i in l:sum+=i
	a=float(sum)/n
	sum2=.0
	for i in l:sum2+=(i-a)**2
	print math.sqrt(sum2/n)