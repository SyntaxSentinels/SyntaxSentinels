# Renamed variables and manually calculates mean

import math  

while 1:  
    total = 0  
    num = int(input())  
    if num == 0:  
        break  
    data = list(map(int, input().split()))
    num += len(data)
    avg = sum(data) / num  # Manual mean calculation
    for x in data:  
        total += (x - avg)**2  
    print(math.sqrt(total / num))  