import math

i = 0
while i<1:

    if  input() == '0':
        break

    arr = list(map(int, input().split()))
    mean = sum(arr) / len(arr)
    sum = 0
    for num in arr:
        sum += math.pow(num - mean, 2)
    a = math.sqrt(sum/len(arr))
    print(a)
