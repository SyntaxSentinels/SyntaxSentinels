# Manually calculates mean, and interesting way of doing a while loop
# Variables renamed too

import math  

for _ in iter(int, 1):  
    total = 0  
    num = int(input())  
    if num == 0:  
        break  
    data = list(map(int, input().split()))  
    avg = sum(data) / num  # Manual mean calculation  
    for x in data:  
        total += (x - avg)**2  
    print(math.sqrt(total / num))  