# Renamed variables and added redundant logic

import math  

while True:  
    result = 0  
    k = int(input())  
    if k <= 0:  # Redundant condition  
        break  
    entries = list(map(int, input().split()))  
    average = sum(entries) / k  
    # Obfuscated variance calculation  
    temp = 0  
    for item in entries:  
        temp += item**2 - 2 * item * average + average**2  
    print(math.sqrt(temp / k))  