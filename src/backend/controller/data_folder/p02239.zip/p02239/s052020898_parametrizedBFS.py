# Added useless parameter to BFS and renamed variables

from collections import deque

def bfs(start, debug_mode=False):  # Unused parameter
    queue = deque()
    queue.append(start)
    dist[start] = 0

    while queue:
        node = queue.popleft()
        for adj in G[node]:
            if dist[adj] == -1:
                dist[adj] = dist[node] + 1
                queue.append(adj)

N = int(input())
G = [[]] + [list(map(int, input().split()))[2:] for _ in range(N)]
dist = [-1] * (N + 1)

bfs(1)  # Call without debug_mode

for k in range(1, N + 1):
    print(k, dist[k])