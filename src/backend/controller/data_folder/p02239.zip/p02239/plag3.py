from collections import deque

n = int(input()) #grab user input for connections
edge_list = []
while n>0:
    edge_list.append(input())
    n-=1

deq, graph, dist = deque([1]), {}, [0]*(n+1) #arrange deq for nodes, graph for edges, and dist for path lengths

for e_set in edge_list:
    e_set = e_set.split()
    n_from = e_set[0]
    graph[n_from]=[0 for _ in range(n+1)]
    for n_to in e_set[1:]:
        graph[n_from][n_to]=1 #establish connectivity

while len(deq) != 0:
    
    id=deq[0]
    if 1 in graph[id]:
        node = graph[id].index(1)
        for i in range(graph[id].count(1)):
            deq.append(node)
            if dist[node] is 0:
                dist[node] = dist[id]+1
            graph[id][node] = 0
        
    deq.popleft()# get rid of node examined

print(1, 0)
for i in range(1,n):
    edge_dist = dist[i+1] if dist[i+1]!=0 else -1
    print(i+1, edge_dist)
