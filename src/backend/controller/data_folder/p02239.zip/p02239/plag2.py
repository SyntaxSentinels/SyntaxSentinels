import sys

n = int(input())  
seen = [False] * n
distance = [0] * n

graph_inp = [list(map(int, line.split())) for line in sys.stdin.read().splitlines()]

for i in range(n):
    if len(graph_inp[i]) > 2:
        graph_inp[i] = graph_inp[i][2:]

queue = [1]  

while len(queue) > 0:
    id = queue.pop(0)
    seen[id-1] = True
    for node in graph_inp[id-1]:
        if not seen[node-1]:
            distance[node-1] = distance[id-1] + 1
            queue.append(node)
            seen[node-1] = True
            

for i in range(n):
    path = distance[i] if seen[i] else -1
    print(f'{i+1} {path}')




