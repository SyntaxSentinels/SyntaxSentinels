import sys

# Read the number of nodes (n)
n = int(sys.stdin.readline().strip())

# Initialize lists for graph and depths
G = [None] * (n + 1)
depths = [-1] * (n + 1)

# Read the graph data from the input
for i in range(1, n + 1):
    # Parse each line of input into a list of integers
    v = list(map(int, sys.stdin.readline().split()))
    # Assign the adjacency list starting from the third element onward
    G[v[0]] = v[2:]

# BFS to calculate depths
nodes = [1]  # Start with node 1
depth = 0
while nodes:
    new_nodes = []
    for node in nodes:
        if depths[node] == -1:  # If this node hasn't been visited
            depths[node] = depth  # Assign the current depth to the node
            new_nodes.extend(G[node])  # Add its neighbors to the list
    depth += 1  # Increment the depth after processing all nodes at the current depth
    nodes = new_nodes  # Update the nodes list for the next level

# Output the depth of each node
for i in range(1, n + 1):
    print(i, depths[i])