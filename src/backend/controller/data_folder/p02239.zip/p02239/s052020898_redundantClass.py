# Renamed variables, changed how variables are instantiated

from collections import deque as dq


# Useless and redundant class
class FakeUtil:
    def __init__(self):
        self.nonsense = 3.14
    def fake_method(self):  # Never called
        return "irrelevant"

def traverse_graph(root):
    q = dq()
    q.append(root)
    levels = {root:0}
    
    while q:
        current = q.popleft()
        for adjacent in adjacency_list[current]:
            if adjacent not in levels:
                levels[adjacent] = levels[current] + 1
                q.append(adjacent)
    return levels

vertex_count = int(input())
adjacency_list = [[]]
for vertex_id in range(1, vertex_count+1):
    raw = list(map(int, input().split()))
    adjacency_list.append(raw[2:])  # Same slicing

# Redundant class instance
dummy = FakeUtil()
distances = [-1]*(vertex_count+1)
bfs_result = traverse_graph(1)

for node in bfs_result:
    distances[node] = bfs_result[node]

for j in range(1, vertex_count+1):
    print(f"{j} {distances[j]}")