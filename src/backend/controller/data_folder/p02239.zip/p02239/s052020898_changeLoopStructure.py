#loop logic restructured

from collections import deque

def bfs(start):
    Q = deque()
    Q.append(start)
    dist[start] = 0

    while Q:
        v = Q.popleft()
        for nv in G[v]:
            if dist[nv] == -1:
                dist[nv] = dist[v] + 1
                Q.append(nv)
            # Redundant check (no effect)
            elif dist[nv] >= 0:
                pass

N = int(input())
G = [[]] + [list(map(int, input().split()))[2:] for _ in range(N)]
dist = [-1] * (N + 1)

bfs(1)


for i in range(1, N + 1):
    print(i, dist[i])