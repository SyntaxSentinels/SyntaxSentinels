n=int(input())

a1=1
a=1

i=1
while i<n:
    a1,a=a,a1+a
    i+=1


print(a)
