#fib function starts here
b = [1,1]
n = int(input())
i = 0
while i < n:
    fib=b[i]+b[i+1]
    b.append(fib)
    i += 1
print(b[n])
