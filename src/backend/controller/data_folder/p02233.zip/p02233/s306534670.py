n=int(input())
num=[1,1]
for i in range(43):
    b=(num[-2])+(num[-1])
    num.append(b)
print(num[(n)])
