

buff = [-1 for _ in range(0,1000)]

def fib(x):
    if buff[x] != -1:
        return buff[x]
    
    if x in [0,1]:
        result=1
        buff[x] = result
        return result
    
    result = fib(x-2) + fib(x-1)
    buff[x] = result
    return result

print(fib(int(input())))
