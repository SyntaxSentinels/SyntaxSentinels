p,n=(1+5**.5)/2,int(input())+1
print(int((p**n-(1-p)**n)/5**.5))
