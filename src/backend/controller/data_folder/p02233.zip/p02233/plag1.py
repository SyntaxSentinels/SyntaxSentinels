
table = {0: 1, 1: 1}

def fibonacci(n):
    if n not in table:
        table[n] = fibonacci(n - 1) + fibonacci(n - 2)
        pass

    return table[n]


n = int(input())
print(fibonacci(n))

