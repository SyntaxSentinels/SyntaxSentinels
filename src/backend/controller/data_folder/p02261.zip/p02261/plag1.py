import sys

class PlayingCard:
    def __init__(self, card):
        self.card = card
        self.suit = card[0]
        self.rank = int(card[1])

    def __str__(self):
        return self.card

def print_cards(cards):
    print(' '.join(str(card) for card in cards))

def swap_elements(arr, i, j):
    arr[i], arr[j] = arr[j], arr[i]

def bubble_sort_cards(cards, n):
    swap_count = 0
    for i in range(n):
        for j in range(n - 1, i, -1):
            if cards[j].rank < cards[j - 1].rank:
                swap_elements(cards, j, j - 1)
                swap_count += 1
    return swap_count

def selection_sort_cards(cards, n):
    is_stable = True
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            if cards[j].rank < cards[min_index].rank:
                min_index = j
        if min_index != i:
            # Check for stability by inspecting the middle section
            for k in range(i + 1, min_index):
                if cards[k].rank == cards[i].rank:
                    is_stable = False
            swap_elements(cards, i, min_index)
    return is_stable

def main():
    n = int(input())  # Need integer amount of cards
    card_input = input().split()  # Input cards as space-separated string
    original_cards = [PlayingCard(card) for card in card_input]
    bubble_sort_cards_copy = [PlayingCard(card) for card in card_input]  # Duplicate for sorting
    selection_sort_cards_copy = [PlayingCard(card) for card in card_input]  # Duplicate for sorting

    bubble_swap_count = bubble_sort_cards(bubble_sort_cards_copy, n)

    selection_sort_stability = selection_sort_cards(selection_sort_cards_copy, n)

    print_cards(bubble_sort_cards_copy)
    print('Stable')
    print_cards(selection_sort_cards_copy)
    if selection_sort_stability:
        print('Stable')
    else:
        print('Not stable')

if __name__ == "__main__":
    main()
