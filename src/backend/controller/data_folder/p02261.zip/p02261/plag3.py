
def swap(i, j, arr):
    arr[i], arr[j] = arr[j], arr[i]

class SORTERS:
    @staticmethod
    def bub(a):
        n = len(a)
        r = a[:]
        for i in range(n):
            for j in range(0,i-1):
                if min(int(r[j][1]),int(r[j+1][1]))==int(r[j+1][1]):
                    swap(j, j-1, r)

        print("Stable")

    @staticmethod
    def sel(a):
        n = len(a)
        r = a[:]
        ret = "Stable"
        for i in range(n):
            min_index = i
            for j in range(i, n):
                if min(int(r[j][1]),int(r[min_index][1])) == int(r[j][1]):
                    min_index = j
            swap(i,min_index, r)
        
        SORTERS.check_stab(a,r)
    
    @staticmethod
    def check_stab(a,r):
        for i in range(n):
            for j in range(i+1, n):
                for k in range(n):
                    for l in range(k+1, n):
                        if int(a[i][1]) == int(a[j][1]) and a[i] == r[l] and a[j] == r[k]:
                            ret = "Not stable"

        print(ret)


_ = int(input())
inp_arr = list(input().split())

SORTERS.bub(inp_arr)
SORTERS.sel(inp_arr)

