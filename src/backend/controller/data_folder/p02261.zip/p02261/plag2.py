 
def selection(copy_inp, n):
    selection_count = 0
    for i in range(n):
        min_ind = i
        for j in range(i, n):
            if copy_inp[j] < copy_inp[min_ind]:
                min_ind = j
        copy_inp[i], copy_inp[min_ind] = copy_inp[min_ind], copy_inp[i]
        if i != min_ind:
            selection_count += 1

    result = " ".join([str(num) for num in copy_inp])
    return result

def bubble(input_array, n):
    is_sorted, swaps_made, sorted_index = False, 0, 0
    
    while not is_sorted:
        is_sorted = True  

        for index in range(n - 1, sorted_index, -1):
            if input_array[index] < input_array[index - 1]:
                
                input_array[index], input_array[index - 1] = input_array[index - 1], input_array[index]
                is_sorted = False  
                swaps_made += 1
        
        sorted_index += 1  

    result = " ".join(input_array)
    return result

#check if stable selection sort was possible to do

def stable_check():
    n = int(input())
    user_inp = [x for x in input().split()]
    copy_inp = []
    for i in range(len(user_inp)):
        copy_inp.append(i)

    ans = bubble(input_array=user_inp, n=n) == selection(copy_inp=copy_inp, n=n)

    print(f"Stable: {ans}")

if __name__ == '__main__':
    stable_check()