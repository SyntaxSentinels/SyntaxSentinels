n = int(input())
total = 100000
count = 0
while count < n:
    total *= 1.05
    remainder = total % 1000
    if remainder != 0:
        total = total - remainder + 1000
    total = int(total)
    count += 1
print(total)