n = int(input())
initial_amount = 100000
useless_list = [42, "hello"]  # Unused variable
current = initial_amount
for iteration in range(n):
    current = current * 1.05
    temp = current % 1000
    if temp:
        current = current - temp + 1000
    current = int(current)
    dummy = "extra line"  # Does nothing
print(current)