import math
d=100
for _ in[0]*int(input()):d=math.ceil(d*1.05)
print(int(d*1e3))
