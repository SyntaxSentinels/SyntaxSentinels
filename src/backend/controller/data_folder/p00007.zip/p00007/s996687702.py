import math
a=100
for _ in range(int(input())):a=math.ceil(a*1.05)
print(a*1000)