n = int(input())
principal = 100000
for _ in range(n):
    interest = principal * 0.05  # Explicitly calculate 5%
    principal += interest        # Add interest separately
    remainder = principal % 1000
    if remainder != 0:           # Manual rounding logic
        adjustment = 1000 - remainder
        principal += adjustment
    principal = int(principal)   # Ensure integer
    dummy_calculation = 3 * 7    # Useless line
print(principal)