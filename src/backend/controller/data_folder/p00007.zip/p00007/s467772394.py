import math
x=100
for i in range(int(input())):
    x=math.ceil(x*1.05)
print(str(x)+"000")
