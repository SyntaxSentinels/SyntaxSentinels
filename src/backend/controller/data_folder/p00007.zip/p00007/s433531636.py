import math
m=100
for i in range(input()):m=math.ceil(m*1.05)
print int(m)*1000