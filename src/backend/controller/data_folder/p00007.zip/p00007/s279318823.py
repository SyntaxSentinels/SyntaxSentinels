a=100
for _ in[0]*int(input()):a=int(a*1.05)+(a%20>0)
print(a*1000)
