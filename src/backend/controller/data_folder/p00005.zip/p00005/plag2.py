import sys, fractions
for x in sys.stdin:
    [print(f"{int(fractions.gcd(l[0], l[1]))} {int(l[0] * l[1] / fractions.gcd(l[0], l[1]))}") for l in [[int(y) for y in x.split()]]] 