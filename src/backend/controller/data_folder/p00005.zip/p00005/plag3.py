import sys

for line in sys.stdin:
    arr = [int(i) for i in line.replace("\n", "").split(" ")]
    arr.sort()
    num1 = arr[0]
    num2 = arr[1]
    while num2 % num1:
        num2, num1 = num1,  num2 % num1
    print(f"{int(num1)} {int(arr[0] / num1 * arr[1])}")