import sys

def euc(a,b):
    if max(a,b)%min(a,b) != 0:
        return euc(min(a,b), max(a,b)%min(a,b))
    else:
        return min(a,b)


for line in sys.stdin:
    for i in line.split():
        a,b = [int(i)]
        print(euc(a,b),int(a*b/euc(a,b)))
