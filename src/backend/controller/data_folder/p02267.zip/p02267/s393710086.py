n = int(input())
S = set(input().split())
q = int(input())
T = set(input().split())

print(len(S & T))
