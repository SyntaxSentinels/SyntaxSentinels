num_elements = int(input())
element_list = list(map(int, input().split()))
num_queries = int(input())
query_list = list(map(int, input().split()))

element_set = set(element_list)
matching_count = sum(1 for query in query_list if query in element_set)

print(str(matching_count))