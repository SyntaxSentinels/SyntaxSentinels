input()
S = input().split()
input()
print(len([s for s in input().split() if s in S]))
