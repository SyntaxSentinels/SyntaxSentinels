n = int(input())
s = set(input().split())
q = int(input())
t = set(input().split())

print(len(s & t))