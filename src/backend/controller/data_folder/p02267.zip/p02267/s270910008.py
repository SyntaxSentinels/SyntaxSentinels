input()
a = set(input().split())
input()
b = set(input().split())
print(len(a & b))

