def linear_search():
	input()
	s = set(input().split())
	input()
	t = set(input().split())
	print(len(s & t))	

if __name__ == '__main__':
	linear_search()