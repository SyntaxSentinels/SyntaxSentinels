n = raw_input()
S = set(raw_input().split())

q = raw_input()
T = set(raw_input().split())

print len(S & T)