n = input()
s = set(input().split())
q = input()
t = set(input().split())

print(len(s & t))