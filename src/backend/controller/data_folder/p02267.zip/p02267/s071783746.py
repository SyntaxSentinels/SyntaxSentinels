n = int(input())
S = list(map(int, input().split()))
q = int(input())
T = list(map(int, input().split()))
ans = 0
for i in range(q):
    if T[i] in S:
        ans += 1
print(ans)
