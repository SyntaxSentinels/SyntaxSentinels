def linearSearch(sequence, target):
    for index, value in enumerate(sequence):
        if value == target:
            return index
    return 'Not_found'

if __name__ == '__main__':
    found_count = 0
    sequence_length = int(input())
    sequence = [int(x) for x in input().split()]
    queries_count = int(input())
    
    for target in (int(x) for x in input().split()):
        if linearSearch(sequence, target) != 'Not_found':
            found_count += 1
    
    print(found_count)