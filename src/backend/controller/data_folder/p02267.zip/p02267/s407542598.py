input()
s=set(input().split())
print(int(input())-len(set(input().split())-s))
