input()
a=input().split()
input()
print(len(set(a)&set(input().split())))