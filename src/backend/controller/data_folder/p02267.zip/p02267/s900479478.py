input()
s=set(input().split())
input()
print(len(s&set(input().split())))
