input()
n1 = set(input().split())
input()
n2 = set(input().split())

print(len(n1&n2))
