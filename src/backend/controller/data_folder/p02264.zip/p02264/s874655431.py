import sys
from collections import deque
s=sys.stdin.readlines()
q=int(s[0].split()[1])
d=deque(list(e.split())for e in s[1:])
t=0
while d:
 k,v=d.popleft();v=int(v)
 if v>q:v-=q;t+=q;d.append([k,v])
 else:t+=v;print(k,t)
