# Using deque instead of a list

from collections import deque  

n_tasks, quantity = map(int, input().split())  

task_queue = deque()  
for _ in range(n_tasks):  
    name, time = input().split()  
    task_queue.append((name, int(time)))  

current_time = 0  
while task_queue:  
    task_name, time = task_queue.popleft()  
    if time <= quantity:  
        current_time += time  
        print(f"{task_name} {current_time}")  
    else:  
        current_time += quantity  
        task_queue.append((task_name, time - quantity))  