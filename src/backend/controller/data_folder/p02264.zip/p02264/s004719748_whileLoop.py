n, time_slice = map(int, input().split())  

job_list = []  
for _ in range(n):  
    name, duration = input().split()  
    job_list.append((name, int(duration)))  

total_time = 0  
ptr = 0  # Manual index pointer  

# Simulate queue via index tracking instead of popping  
while ptr < len(job_list):  
    task_name, remaining = job_list[ptr]  
    if remaining <= time_slice:  
        total_time += remaining  
        print(f"{task_name} {total_time}")  
    else:  
        total_time += time_slice  
        job_list.append((task_name, remaining - time_slice))
    ptr += 1