n, quantity = map(int, input().split())  

tasks = []  
for _ in range(n):  
    name, time = input().split()  
    tasks.append((name, int(time)))  

total_time = 0  
# Infinite loop using iter(int, 1)  
for _ in iter(int, 1):  
    if not tasks:  
        break  
    current_name, rem_time = tasks.pop(0)  
    if rem_time <= quantity:  
        total_time += rem_time  
        print(f"{current_name} {total_time}")  
    else:  
        total_time += quantity  
        tasks.append((current_name, rem_time - quantity))  