from math import *
print(gcd(*map(int, input().split())))
