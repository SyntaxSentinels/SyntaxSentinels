from fractions import gcd
x, y = map(int, input().split())
print(gcd(x, y))