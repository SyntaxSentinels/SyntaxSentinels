def main():
    x, y = map(int, input().split(' '))
    print(gcd(x, y))

def gcd(x, y):
    if x < y:
        x, y = y, x

    if x % y == 0:
        return y

    return gcd(y, x%y)

if __name__ == '__main__':
    main()