from fractions import gcd

a, b = list(map(int, input().split()))
print(gcd(a,b))