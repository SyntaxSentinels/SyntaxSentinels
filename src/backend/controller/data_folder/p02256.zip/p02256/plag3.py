a,b = [int(i) for i in input().split()]

def gcd(a,b):
 a,b = sorted([a,b])
 while b > 0:
  a, b = b, a % b
 return a

print(f"{gcd(a,b)}")