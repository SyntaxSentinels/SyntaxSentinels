def main():
    x, y = map(int, input().split())
    print(compute_gcd(x, y))

def compute_gcd(num1, num2):
    while num2 != 0:
        if num1 < num2:
            num1, num2 = num2, num1
        remainder = num1 % num2
        num1 = num2
        num2 = remainder
    return num1


main()