num1 = int(input)
num2 = int(input)

smaller, larger = sorted((num1, num2))

while larger % smaller:
    smaller, larger = larger % smaller, smaller

print(smaller)