# Useless parameter added, and renamed variables. slight logic change

def main():
    a, b = map(int, input().split())
    print(gcd_calculator(a, b))

def gcd_calculator(m, n, dummy_arg=None):  # Unused parameter
    if m < n:
        m, n = n, m
    mod = m % n
    if mod == 0:
        return n
    else:
        return gcd_calculator(n, mod)


main()