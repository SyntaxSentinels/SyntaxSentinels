from math import gcd
x,y = [int(i) for i in input().split()]
print(gcd(x,y))

