def calculate_gcd(a, b):
    while b:
        a, b = b, a % b
    return a

num1, num2 = map(int, input().split())
if num1 > num2:
    calculate_gcd(num1, num2)
else:
    calculate_gcd(num2, num1)