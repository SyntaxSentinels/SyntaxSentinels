import math
line=input().split()
x=int(line[0])
y=int(line[1])
print(math.gcd(x,y))

