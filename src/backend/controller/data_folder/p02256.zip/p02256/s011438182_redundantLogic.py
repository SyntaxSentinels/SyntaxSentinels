def main():
    input_values = input().split()
    X_val = int(input_values[0])
    Y_val = int(input_values[1])
    # Unnecessary
    result = greatest_common_divisor(X_val, Y_val)
    print(result)

def greatest_common_divisor(a, b):
    if a < b:
        temp = a
        a = b
        b = temp
    remainder = a % b
    if remainder != 0:
        return greatest_common_divisor(b, remainder)
    else:
        return b  # Explicit return


main()