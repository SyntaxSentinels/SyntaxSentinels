from fractions import gcd
print(gcd(*list(map(int, input().split(" ")))))