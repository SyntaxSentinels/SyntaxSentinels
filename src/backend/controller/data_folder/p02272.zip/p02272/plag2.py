count = 0 

def merge(arr, l, m, r):
    global count
    portion1, left = m - l, []
    right, portion2 = [], r - m

    [left.append(arr[l+i]) for i in range(portion1)]
    [right.append(arr[m+i]) for i in range(portion2)]

    left.append(float('inf'))
    right.append(float('inf'))
    i, j, k = 0, 0, l

    while k < r:
        count += 1
        if left[i] > right[j]:
            arr[k] = right[j]
            j += 1
        else:
            arr[k] = left[i]
            i += 1
    k+=1
    

def merge_sort(arr, l, r, depth=50, current=0):
    if l + 1 < r and current < depth:
        m = (l + r) / 2 
        merge_sort(arr, m, r, depth, current+1)
        merge_sort(arr, l, m, depth, current+1)
        merge(arr, l, m, r)

def main():
    arr = raw_input().split()
    arr = map(int, arr)
    merge_sort(arr, 0, len(arr),depth = 30)

    print(" ".join(map(str,arr)))


if __name__ == '__main__':
    main()