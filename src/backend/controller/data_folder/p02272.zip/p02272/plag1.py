from array import array

merge_operations = 0

def merge_and_count(array, left_start, mid_point, right_end):
    INF = float('inf')
    global merge_operations

    left_part = array[left_start:mid_point] + [INF]
    right_part = array[mid_point:right_end] + [INF]

    left_idx = right_idx = 0

    for i in range(left_start, right_end):
        if left_part[left_idx] <= right_part[right_idx]:
            array[i] = left_part[left_idx]
            left_idx += 1
        else:
            array[i] = right_part[right_idx]
            right_idx += 1

        merge_operations += 1


def mergeSort(inp_arr,left,right):
    if(left+1<right):
        mid=(left+right)//2
        mergeSort(inp_arr,left,mid)
        mergeSort(inp_arr,mid,right)
        merge_and_count(inp_arr,left,mid,right)
    return

def main(n,inp_arr):
    global count
    mergeSort(inp_arr,0,n)
    return inp_arr,count

if __name__=='__main__':
    inp_arr,count=main(int(input()),[int(i) for i in input().split()])
    print(' '.join(map(str,inp_arr)))
    print(count)
