from collections import deque

num_elements = int(input())
data = list(map(int, input().split()))
INFINITY = float('inf')

def merge(arr, left, mid, right):
    global operation_count
    left_segment = deque(arr[left:mid])
    right_segment = deque(arr[mid:right])
    left_segment.append(INFINITY)
    right_segment.append(INFINITY)
    
    for i in range(left, right):
        if left_segment[0] <= right_segment[0]:
            arr[i] = left_segment.popleft()
        else:
            arr[i] = right_segment.popleft()
    
    operation_count += right - left

def merge_sort(arr, left, right):
    if left + 1 < right:
        mid = (left + right) // 2
        merge_sort(arr, left, mid)
        merge_sort(arr, mid, right)
        merge(arr, left, mid, right)

operation_count = 0
merge_sort(data, 0, num_elements)
print(*data)
print(operation_count)
