# Pre-load data into array and then do same thing

n = int(input())  
data = [int(input()) for _ in range(n)]  

min_val = data[0]  
result = -10**10  

for num in data[1:]:  # Iterate over preloaded list 
    diff = num - min_val
    if diff > result:
        result = diff
    min_val = min(min_val, num)  

print(result)  