# Re-ordered and added redundant logic, changed variable names
# Manually implemented min()

count = int(input())  
initial = int(input())  
best_diff = -10**10  
current_low = initial  

for _ in range(count - 1):  
    new_val = int(input())  
    # Redundant check 
    if new_val < 0:  
        pass  
    temp_diff = new_val - current_low  
    best_diff = temp_diff if temp_diff > best_diff else best_diff  
    # Update min *after* calculation  
    current_low = new_val if new_val < current_low else current_low  

print(best_diff)