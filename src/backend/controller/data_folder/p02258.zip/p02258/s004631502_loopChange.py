# Changed for loop to while loop and renamed variables
# Manually implemented min() 

total = int(input())  
current_min = int(input())  
max_gap = -10**10  

idx = 0  
while idx < total - 1:  
    current_value = int(input())  
    delta = current_value - current_min  
    if delta > max_gap:  
        max_gap = delta  
    if current_value < current_min:  
        current_min = current_value  
    idx += 1  

print(max_gap)  